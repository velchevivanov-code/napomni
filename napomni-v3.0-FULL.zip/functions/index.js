const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();

/**
 * deadlineNotifier — изпраща push известия за предстоящи счетоводни срокове
 *
 * Работи всеки ден в 08:00 ч. (Europe/Sofia)
 * Изпраща при: 7 дни, 1 ден, в деня на срока
 *
 * ⚠️ Изисква Firebase Blaze план (billing) за Cloud Functions schedule
 */
exports.deadlineNotifier = functions.pubsub
  .schedule("every day 08:00")
  .timeZone("Europe/Sofia")
  .onRun(async () => {
    const db = admin.firestore();
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Вградени срокове (same logic as client BDB)
    const Y = today.getFullYear();
    const mo = (m, d) => `${Y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;

    const staticDeadlines = [
      // ДДС — 14-то число всеки месец
      ...Array.from({ length: 12 }, (_, i) => ({
        id: `vat${i}`,
        date: mo(i + 1, 14),
        title: "Справка-декларация ЗДДС",
        group: "ДДС",
        vat: true,
      })),
      // Осигуровки работодатели — 25-то
      ...Array.from({ length: 12 }, (_, i) => ({
        id: `osw${i}`,
        date: mo(i + 1, 25),
        title: "Осигуровки — работодатели",
        group: "Осигуровки",
        emp: true,
      })),
      // Осигуровки СОЛ — 25-то
      ...Array.from({ length: 12 }, (_, i) => ({
        id: `oss${i}`,
        date: mo(i + 1, 25),
        title: "Осигуровки — СОЛ",
        group: "Осигуровки",
        sol: true,
      })),
      // Годишни
      { id: "kpo", date: mo(3, 31), title: "Годишна декларация ЗКПО", group: "Годишни" },
      { id: "ddfl", date: mo(4, 30), title: "Годишна декларация ЗДДФЛ", group: "Годишни" },
      { id: "gfo", date: mo(6, 30), title: "ГФО в Търговски регистър", group: "Годишни" },
      { id: "nsi", date: mo(2, 28), title: "Годишен отчет — НСИ", group: "Статистика" },
      { id: "ndi1", date: mo(6, 30), title: "Данък имоти — I вноска", group: "Данъци" },
      { id: "ndi2", date: mo(10, 31), title: "Данък имоти — II вноска", group: "Данъци" },
      { id: "mps1", date: mo(6, 30), title: "Данък МПС — I вноска", group: "Данъци" },
      { id: "mps2", date: mo(10, 31), title: "Данък МПС — II вноска", group: "Данъци" },
      { id: "inv", date: mo(12, 31), title: "Годишна инвентаризация", group: "Годишни" },
    ];

    // Вземи и custom deadline-ите от Firestore
    let customDeadlines = [];
    try {
      const snap = await db.collection("deadlines").get();
      customDeadlines = snap.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    } catch (e) {
      console.warn("Не мога да взема custom deadlines:", e.message);
    }

    const allDeadlines = [...staticDeadlines, ...customDeadlines];

    // Намери срокове за нотифициране (7 дни, 1 ден, днес)
    const toNotify = allDeadlines.filter((d) => {
      const due = new Date(d.date);
      due.setHours(0, 0, 0, 0);
      const diffDays = Math.ceil((due - today) / (1000 * 60 * 60 * 24));
      return [7, 1, 0].includes(diffDays);
    });

    if (!toNotify.length) {
      console.log("Няма срокове за нотифициране днес");
      return null;
    }

    console.log(`Намерени ${toNotify.length} срока за нотифициране`);

    // Вземи всички FCM токени
    const tokensSnap = await db.collection("fcmTokens").get();
    if (tokensSnap.empty) {
      console.log("Няма регистрирани FCM токени");
      return null;
    }

    // Групирай токени по userId
    const userTokens = {};
    tokensSnap.docs.forEach((doc) => {
      const data = doc.data();
      if (!userTokens[data.userId]) userTokens[data.userId] = [];
      userTokens[data.userId].push({ token: data.token, docId: doc.id });
    });

    // Вземи потребителските данни за филтриране
    const usersSnap = await db.collection("users").get();
    const usersMap = {};
    usersSnap.docs.forEach((doc) => {
      usersMap[doc.id] = doc.data();
    });

    let sent = 0;
    let failed = 0;
    const invalidTokens = [];

    for (const [userId, tokens] of Object.entries(userTokens)) {
      const userData = usersMap[userId];
      const activeCo = (userData?.cos || []).find((c) => c.active);

      // Филтрирай срокове за този потребител
      const relevant = toNotify.filter((d) => {
        if (!activeCo) return true; // без фирма = всички срокове
        if (d.vat && !activeCo.vat) return false;
        if (d.sol && !activeCo.sol) return false;
        if (d.emp && !activeCo.emp) return false;
        return true;
      });

      if (!relevant.length) continue;

      for (const d of relevant) {
        const due = new Date(d.date);
        due.setHours(0, 0, 0, 0);
        const diffDays = Math.ceil((due - today) / (1000 * 60 * 60 * 24));

        const payload = {
          notification: {
            title:
              diffDays === 0
                ? `⚠️ Срок ДНЕС: ${d.title}`
                : diffDays === 1
                ? `⏰ Срок УТРЕ: ${d.title}`
                : `📅 Срок след ${diffDays} дни: ${d.title}`,
            body: d.group + (activeCo ? ` · ${activeCo.name}` : ""),
          },
          data: {
            deadlineId: d.id,
            daysLeft: String(diffDays),
          },
        };

        for (const t of tokens) {
          try {
            await admin.messaging().send({
              token: t.token,
              ...payload,
            });
            sent++;
          } catch (e) {
            failed++;
            // Премахни невалидни токени
            if (
              e.code === "messaging/invalid-registration-token" ||
              e.code === "messaging/registration-token-not-registered"
            ) {
              invalidTokens.push(t.docId);
            }
          }
        }
      }
    }

    // Изчисти невалидните токени
    for (const docId of invalidTokens) {
      try {
        await db.collection("fcmTokens").doc(docId).delete();
      } catch (e) {
        console.warn("Грешка при изтриване на токен:", e.message);
      }
    }

    console.log(`Push нотификации: ${sent} изпратени, ${failed} неуспешни, ${invalidTokens.length} токена изчистени`);
    return null;
  });

/**
 * cleanupTokens — почиства стари FCM токени (по-стари от 60 дни)
 * Работи веднъж седмично
 */
exports.cleanupTokens = functions.pubsub
  .schedule("every monday 03:00")
  .timeZone("Europe/Sofia")
  .onRun(async () => {
    const db = admin.firestore();
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - 60);

    const snap = await db
      .collection("fcmTokens")
      .where("lastRefresh", "<", cutoff)
      .get();

    let deleted = 0;
    for (const doc of snap.docs) {
      await doc.ref.delete();
      deleted++;
    }

    console.log(`Изчистени ${deleted} стари FCM токена`);
    return null;
  });
